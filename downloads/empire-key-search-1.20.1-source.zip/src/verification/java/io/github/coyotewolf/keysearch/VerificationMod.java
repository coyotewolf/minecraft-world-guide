package io.github.coyotewolf.keysearchverification;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.gui.screens.controls.KeyBindsList;
import net.minecraft.client.gui.screens.controls.KeyBindsScreen;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

import java.nio.file.Files;
import java.nio.file.Path;

@Mod("empire_key_search_tests")
public final class VerificationMod {
    private int step;
    private int ticks;
    private int original;
    private EditBox search;
    private KeyBindsList list;
    private Button mode;
    private Button clear;
    private InputConstants.Key oldJump;

    public VerificationMod() {
        MinecraftForge.EVENT_BUS.addListener(this::tick);
        Minecraft mc = Minecraft.getInstance();
        mc.execute(() -> GLFW.glfwHideWindow(mc.getWindow().getWindow()));
    }

    private int keys() {
        return (int) list.children().stream().filter(e -> e.getClass().getSimpleName().equals("KeyEntry")).count();
    }
    private void require(boolean ok, String text) {
        if (!ok) throw new AssertionError(text);
    }
    private void tick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END || ++ticks % 10 != 0) return;
        Minecraft mc = Minecraft.getInstance();
        if (step == 0 && (!(mc.screen instanceof TitleScreen) || mc.getOverlay() != null)) return;
        try {
            switch(step++) {
                case 0 -> {
                    GLFW.glfwHideWindow(mc.getWindow().getWindow());
                    mc.setScreen(new KeyBindsScreen(mc.screen, mc.options));
                    search = mc.screen.children().stream().filter(EditBox.class::isInstance).map(EditBox.class::cast).findFirst().orElseThrow();
                    list = mc.screen.children().stream().filter(KeyBindsList.class::isInstance).map(KeyBindsList.class::cast).findFirst().orElseThrow();
                    clear = mc.screen.children().stream().filter(Button.class::isInstance).map(Button.class::cast).filter(b -> b.getMessage().getString().equals("×")).findFirst().orElseThrow();
                    mode = mc.screen.children().stream().filter(Button.class::isInstance).map(Button.class::cast).filter(b -> b.getMessage().getString().equals("全部") || b.getMessage().getString().equals("All")).findFirst().orElseThrow();
                    original = keys();
                    require(original > 20, "all original bindings available");
                    search.setValue("jump");
                    require(keys() == 1, "action name search");
                }
                case 1 -> {
                    search.setValue("跳躍");
                    require(keys() == 1, "Chinese search");

                }
                case 2 -> {
                    Screenshot.grab(mc.gameDirectory, "key-search-verification.png", mc.getMainRenderTarget(), c -> {});
                    search.setValue("Space");
                    require(keys() >= 1, "key label search");
                    search.setValue("movement");
                    require(keys() >= 1, "category/mod name search");
                    search.setValue("not-a-real-key-function");
                    require(keys() == 0 && list.children().isEmpty(), "no matches and no empty categories");
                    clear.onPress();
                    require(keys() == original, "clear restores all entries");
                    oldJump = mc.options.keyJump.getKey();
                    mc.options.keyJump.setKey(InputConstants.UNKNOWN);
                    mode.onPress();
                    require(keys() >= 1, "unbound filter");
                }
                case 3 -> {
                    mc.options.keyJump.setKey(mc.options.keyUp.getKey());
                    mode.onPress();
                    require(keys() >= 2, "conflict filter after rebinding");
                    mc.options.keyJump.setKey(oldJump);
                    clear.onPress();
                    require(keys() == original, "restore after changing key");
                    mc.screen.resize(mc, 320, 240);
                    require(mc.screen.children().stream().anyMatch(EditBox.class::isInstance), "resized search preserved");
                    Files.writeString(Path.of("key-search-verification.json"), "{\"passed\":true,\"checks\":[\"all bindings\",\"action search\",\"Chinese search\",\"key search\",\"category search\",\"no results\",\"clear\",\"unbound\",\"conflict after rebind\",\"resize\"]}");
                    mc.stop();
                }
            }
        } catch (Throwable error) {
            try { Files.writeString(Path.of("key-search-verification.json"), "{\"passed\":false,\"error\":\"" + error.toString().replace("\"", "'") + "\"}"); } catch(Exception ignored) {}
            error.printStackTrace();
            mc.stop();
        }
    }
}
