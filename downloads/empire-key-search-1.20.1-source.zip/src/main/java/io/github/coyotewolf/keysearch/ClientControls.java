package io.github.coyotewolf.keysearch;

import com.mojang.logging.LogUtils;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.controls.KeyBindsList;
import net.minecraft.client.gui.screens.controls.KeyBindsScreen;
import net.minecraft.client.resources.language.I18n;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.ModList;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.event.TickEvent;
import org.slf4j.Logger;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.WeakHashMap;

@Mod.EventBusSubscriber(modid = KeySearchMod.ID, value = Dist.CLIENT)
public final class ClientControls {
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final WeakHashMap<Screen, State> STATES = new WeakHashMap<>();
    private static int ticks;

    @SubscribeEvent
    public static void close(ScreenEvent.Closing event) {
        STATES.remove(event.getScreen());
    }

    @SubscribeEvent
    public static void tick(TickEvent.ClientTickEvent event) {
        if (event.phase == TickEvent.Phase.END && ++ticks % 10 == 0) {
            refresh(Minecraft.getInstance().screen);
        }
    }

    @SubscribeEvent
    public static void init(ScreenEvent.Init.Post event) {
        if (!(event.getScreen() instanceof KeyBindsScreen screen)) return;
        // Controlling already supplies a full replacement; avoid overlapping controls.
        if (ModList.get().isLoaded("controlling")) return;
        for (var child : screen.children()) {
            if (!(child instanceof KeyBindsList list)) continue;
            try {
                State old = STATES.get(screen);
                State state = new State(list);
                if (old != null) { state.query = old.query; state.mode = old.mode; }
                int left = Math.max(8, screen.width / 2 - 155);
                int width = Math.min(310, screen.width - 16);
                EditBox search = new EditBox(Minecraft.getInstance().font, left, 25,
                        width - 112, 20, Component.translatable("empire_key_search.search"));
                search.setMaxLength(160);
                search.setHint(Component.translatable("empire_key_search.search"));
                search.setValue(state.query);
                search.setResponder(query -> { state.query = query; state.filter(true); });
                Button filter = Button.builder(state.modeLabel(), button -> {
                    state.mode = (state.mode + 1) % 3;
                    button.setMessage(state.modeLabel());
                    state.filter(true);
                }).bounds(left + width - 106, 25, 78, 20).build();
                filter.setTooltip(Tooltip.create(Component.translatable("empire_key_search.filter_tip")));
                Button clear = Button.builder(Component.literal("×"), button -> {
                    state.mode = 0;
                    filter.setMessage(state.modeLabel());
                    search.setValue("");
                    state.filter(true);
                    search.setFocused(true);
                    screen.setFocused(search);
                }).bounds(left + width - 22, 25, 22, 20).build();
                clear.setTooltip(Tooltip.create(Component.translatable("empire_key_search.clear")));
                list.updateSize(screen.width, screen.height, 64, screen.height - 32);
                event.addListener(search);
                event.addListener(filter);
                event.addListener(clear);
                STATES.put(screen, state);
                state.filter(true);
            } catch (ReflectiveOperationException | RuntimeException error) {
                LOGGER.error("Could not attach key search; original controls remain available", error);
            }
            break;
        }
    }

    @SubscribeEvent
    public static void render(ScreenEvent.Render.Post event) {
        State state = STATES.get(event.getScreen());
        if (state == null) return;
        var font = Minecraft.getInstance().font;
        event.getGuiGraphics().drawCenteredString(font,
                Component.translatable("empire_key_search.results", state.visible, state.total),
                event.getScreen().width / 2, 50, 0xAAAAAA);
    }

    @SubscribeEvent
    public static void keyReleased(ScreenEvent.KeyReleased.Post event) {
        refresh(event.getScreen());
    }

    @SubscribeEvent
    public static void mouseReleased(ScreenEvent.MouseButtonReleased.Post event) {
        refresh(event.getScreen());
    }

    private static void refresh(Screen screen) {
        State state = STATES.get(screen);
        if (state != null) state.filter(false);
    }

    private record Row(KeyBindsList.Entry entry, KeyMapping mapping) {}

    private static final class State {
        final KeyBindsList list;
        final List<Row> rows = new ArrayList<>();
        int mode;
        int visible;
        int total;
        String query = "";

        State(KeyBindsList list) throws ReflectiveOperationException {
            this.list = list;
            // Identify the backing binding by type, independent of obfuscated field names.
            for (KeyBindsList.Entry entry : List.copyOf(list.children())) {
                KeyMapping mapping = null;
                for (Field field : entry.getClass().getDeclaredFields()) {
                    if (field.getType() == KeyMapping.class) {
                        field.setAccessible(true);
                        mapping = (KeyMapping) field.get(entry);
                        break;
                    }
                }
                rows.add(new Row(entry, mapping));
                if (mapping != null) total++;
            }
            if (total == 0) throw new IllegalStateException("No vanilla key entries found");
        }

        Component modeLabel() {
            return Component.translatable("empire_key_search." +
                    new String[]{"all", "unbound", "conflicts"}[mode]);
        }

        boolean matches(KeyMapping key) {
            if (mode == 1 && !key.isUnbound()) return false;
            if (mode == 2) {
                if (key.isUnbound()) return false;
                boolean conflict = false;
                for (KeyMapping other : Minecraft.getInstance().options.keyMappings) {
                    if ((other != key && key.same(other)) || other.hasKeyModifierConflict(key)) {
                        conflict = true;
                        break;
                    }
                }
                if (!conflict) return false;
            }
            if (query.isBlank()) return true;
            String text = I18n.get(key.getName()) + " " + I18n.get(key.getCategory()) +
                    " " + key.getName() + " " + key.getCategory() + " " +
                    key.getTranslatedKeyMessage().getString() + " " + key.saveString() + " " +
                    key.saveString().replace("control", "ctrl").replace("keypad", "numpad") + " " +
                    key.getKeyModifier().toString();
            for (var mod : ModList.get().getMods()) {
                String id = mod.getModId();
                if (key.getName().contains("." + id + ".") ||
                        key.getCategory().contains("." + id)) text += " " + mod.getDisplayName();
            }
            return SearchMatcher.matches(query, text);
        }

        void filter(boolean resetScroll) {
            List<KeyBindsList.Entry> shown = new ArrayList<>();
            KeyBindsList.Entry category = null;
            visible = 0;
            for (Row row : rows) {
                if (row.mapping == null) { category = row.entry; continue; }
                if (!matches(row.mapping)) continue;
                if (category != null) { shown.add(category); category = null; }
                shown.add(row.entry);
                visible++;
            }
            if (!list.children().equals(shown)) {
                list.children().clear();
                list.children().addAll(shown);
            }
            list.refreshEntries();
            if (resetScroll) list.setScrollAmount(0);
        }
    }
}
