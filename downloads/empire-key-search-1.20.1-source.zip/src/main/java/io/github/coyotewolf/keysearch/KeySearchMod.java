package io.github.coyotewolf.keysearch;

import net.minecraftforge.fml.common.Mod;

@Mod(KeySearchMod.ID)
public final class KeySearchMod {
    public static final String ID = "empire_key_search";
}
