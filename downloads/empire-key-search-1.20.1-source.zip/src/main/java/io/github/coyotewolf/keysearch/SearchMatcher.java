package io.github.coyotewolf.keysearch;

import java.util.Locale;

public final class SearchMatcher {
    private SearchMatcher() {}

    public static boolean matches(String query, String searchable) {
        String text = searchable.toLowerCase(Locale.ROOT);
        for (String token : query.trim().toLowerCase(Locale.ROOT).split("\\s+")) {
            if (!text.contains(token)) return false;
        }
        return true;
    }
}
